//Task 1

// program to check if the string is palindrome or not

function checkPalindrome(string) {

    // find the length of a string
    const len = string.length;

    // loop through half of the string
    for (let i = 0; i < len / 2; i++) {

        
        if (string[i] !== string[len - 1 - i]) {
            return 'It is not a palindrome';
        }
    }
    return 'It is a palindrome';
}


const string = prompt('Enter a string: ');

const value = checkPalindrome(string);

console.log(value);


//Task 2
function bubbleSort(arr){
   
    var i, j;
    var len = arr.length;
     
    var isSwapped = false;
     
    for(i =0; i < len; i++){
       
      isSwapped = false;
       
      for(j = 0; j < len; j++){
          if(arr[j] > arr[j + 1]){
            var temp = arr[j]
            arr[j] = arr[j+1];
            arr[j+1] = temp;
            isSwapped = true;
          }
      }
       
      
      if(!isSwapped){
        break;
      }
    }
     

    console.log(arr)
  }
   
   
  var arr = [243, 45, 23, 356, 3, 5346, 35, 5];
   

  bubbleSort(arr)








//Task 3  
const number = parseInt(prompt('Enter an integer: '));


for(let i = 1; i <= 10; i++) {

    const result = i * number;


    console.log(`${number} * ${i} = ${result}`);
}



