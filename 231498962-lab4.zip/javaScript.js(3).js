function task1(){


    var arr = [4, 8, 7, 13, 12]
    
    var sum = 0;
    
    for (let i = 0; i < arr.length; i++) {
        sum += arr[i];
    }
    
    document.getElementById("sumid").innerHTML=sum;
    }
    function add(){
        let n1 = Number(document.querySelector("#num1").value);
        let n2 = Number(document.querySelector("#num2").value);
        let addi = n1+n2;
        document.getElementById("task2").innerHTML=addi;
    }
    function sub(){
        let n1 = Number(document.querySelector("#num1").value);
        let n2 = Number(document.querySelector("#num2").value);
        let addi = n1-n2;
        document.getElementById("task2").innerHTML=addi;
    }
    function mul(){
        let n1 = Number(document.querySelector("#num1").value);
        let n2 = Number(document.querySelector("#num2").value);
        let addi = n1*n2;
        document.getElementById("task2").innerHTML=addi;
    }
    function div(){
        let n1 = Number(document.querySelector("#num1").value);
        let n2 = Number(document.querySelector("#num2").value);
        let addi = n1/n2;
        document.getElementById("task2").innerHTML=addi;
    }
    
    function task3(){
        var arr1=[-3,8,7,6,5,-4,3,2,1];
        var arr2=[];
        var min=arr1[0];
        var pos;
        var max=arr1[0];
        for (i=0; i<arr1.length; i++){
            if (max<arr1[i]) max=arr1[i];
        }
        for (var i=0;i<arr1.length;i++){
            for (var j=0;j<arr1.length;j++){
                if (arr1[j]!="x"){
                    if (min>arr1[j]) 
                    {
                        min=arr1[j];
                        pos=j;
                    }
                }
            }
            arr2[i]=min;
            arr1[pos]="x";
            min=max;
        }
        document.getElementById("ans3").innerHTML = "Answer is: " + arr2;
    
    }
    
    function form(){
        let n = document.forms["myform"]["name"].value;
        if(n==""){
            
            alert("Name field is empty");
            return false;
        }
        let pass = document.forms["myform"]["password"].value;
        let pass1 = pass.length
        
        if(pass1<=7){
            alert("password lenth is less than 8");
            return false;
        }
    }
    
    
    
    
    function calculateTip() {
        var billAmount = document.getElementById("billamount").value;
        var Quality = document.getElementById("serviceQual").value;
        var totalPeople = document.getElementById("peopleamount").value;
      
        
        if (billAmount === "" || Quality == 0) {
          alert("Please Enter a Value!");
          return;
        }
        
        if (totalPeople === "" || totalPeople <= 1) {
            totalPeople = 1;
          document.getElementById("each").style.display = "none";
        } else {
          document.getElementById("each").style.display = "block";
        }
      
        
        var totalTip = (billAmount * Quality) / totalPeople;
        document.getElementById("totalTip").style.display = "block";
        document.getElementById("tip").innerHTML = totalTip;
      
      }